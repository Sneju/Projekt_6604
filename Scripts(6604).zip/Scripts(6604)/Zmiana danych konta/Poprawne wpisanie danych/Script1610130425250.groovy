import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

/*  Otworzenie przeglądarki i przejscie na stronę phptravels.net  */
WebUI.openBrowser(rawUrl = GlobalVariable.url)

/*  Kliknięcie na pole ,,MY ACCOUNT''  */
WebUI.click(findTestObject('Object Repository/Przejscie do logowania/klika_account'))

/*  Klikniecie na pole ,,Login''  */
WebUI.click(findTestObject('Object Repository/Przejscie do logowania/klika_login'))

/*   Wpisanie loginu  */
WebUI.setText(findTestObject('Object Repository/Logowanie/Wpisywanie loginu'), GlobalVariable.loginid)

/*  Wpisanie hasla  */
WebUI.setEncryptedText(findTestObject('Object Repository/Logowanie/Wpisywanie hasla'), GlobalVariable.pwd)

/*  Klikniecie LOGIN  */
WebUI.click(findTestObject('Object Repository/Logowanie/klikniecie LOGIN'))

/*  Przejscie do edycji profilu  */
WebUI.click(findTestObject('Object Repository/Edycja profilu/Przejscie do edycji'))

/*  Wpisanie danych w polu Email  */
WebUI.setText(findTestObject('Object Repository/Edycja profilu/Wpisz Email'), Email)

/*  Wpisanie danych w polu Password  */
WebUI.setEncryptedText(findTestObject('Object Repository/Edycja profilu/Wpisz haslo'), Password)

/*  Wpisanie danych w polu Confirmed Password  */
WebUI.setEncryptedText(findTestObject('Object Repository/Edycja profilu/Powtorz haslo'), Password)

/*  Wpisanie danych w polu City  */
WebUI.setText(findTestObject('Object Repository/Edycja profilu/Wpisz miasto'), City)

/*  Wpisanie danych w polu State/Region  */
WebUI.setText(findTestObject('Object Repository/Edycja profilu/Wpisz region'), State)

/*  Wpisanie danych w polu Postal Zip Code  */
WebUI.setText(findTestObject('Object Repository/Edycja profilu/Wpisz kod pocztowy'), Postal)

/*  Wpisanie danych w poolu Phone  */
WebUI.setText(findTestObject('Object Repository/Edycja profilu/Wpisz telefon'), Phone)

/*  Kliknij przycisk ,,Submit''  */
WebUI.click(findTestObject('Object Repository/Edycja profilu/Button_Submit'))

